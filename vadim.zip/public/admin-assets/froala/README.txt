Froala WYSIWYG Editor
================

In order to use Froala Editor you have to purchase a license from: https://www.froala.com/wysiwyg-editor/pricing.
For more informations regarding the license please read https://www.froala.com/wysiwyg-editor/terms.
